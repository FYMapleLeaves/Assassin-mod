-- Assassins_GameplayScript
-- Author: yiboy
-- DateCreated: 11/15/2022 4:07:02 PM
--------------------------------------------------------------
--�й��ֺ������ݱ���Ҫ��лKCucumber���еġ��������ѡ�mod

local createDisasterJudge = 0;
local createDisasterFrequency = 10;
local createDisasterStartTurn = 500;
--ÿ�غ϶�δ������������Ƭ�ϵĵ�λ����˺�(���˺����������Ҷ�AI���ǰ��Ұ�����нϸߵ�����)��ֱ��ɱ���������ʬ����ͬһ���ϵĵ�λ��
--������е�λλ�ã�ʩ���˺�
function FindPossibleUnitsAssassins(pPlayerID)
	local pPlayer = Players[pPlayerID];
	if pPlayer==nil then
		return
	end
	local killUnitX = 0
	local killUnitY = 0
	local playerUnits = pPlayer:GetUnits();
	local unitToBeKilledUnitID :table = {}
	for i, unit in playerUnits:Members() do
		local unitInfo = GameInfo.Units[unit:GetType()];
		if (unitInfo) then
			local unitTypeName = unitInfo.UnitType;
			if unitTypeName ~= "UNIT_ASSASSIN" and unitTypeName ~= "UNIT_THE_SHROUD_OF_EDEN" then
				local locationX = unit:GetX()
				local locationY = unit:GetY()
				--if locationX~=nil then
					--print("locationX", locationX)
				--end
				--if locationY~=nil then
					--print("locationY", locationY)
				--end
				local pPlot = Map.GetPlot(locationX, locationY)
				if pPlot ~= nil and unit ~= nil then
					local pPlotResoureceTypeIndex = pPlot:GetResourceType()
					--print("pplot not nil")
					if pPlotResoureceTypeIndex ~= -1 then
						--print("pPlotResoureceTypeIndex", pPlotResoureceTypeIndex)
						if GameInfo.Resources[pPlotResoureceTypeIndex].ResourceType == "RESOURCE_EDEN_PIECE" then
							--print("On EDEN_PIECE")
							local pPlotImprovementType = pPlot:GetImprovementType()
							if pPlotImprovementType~=nil and pPlotImprovementType==-1 then
								--print("pPlotImprovementType", pPlotImprovementType)
								local pPlotDistrictType = pPlot:GetDistrictType()
								--print("pPlotDistrictType", pPlotDistrictType)
								if pPlotDistrictType~=nil and pPlotDistrictType==-1 then									
									--print("EDEN_PIECE damage")
									local unitDamageValue = unit:GetDamage()
									local unitHealth = 100 - unitDamageValue
									--print("unitDamageValue", unitDamageValue)
									--print("unitHealth", unitHealth)
									if pPlayer:IsHuman()  then
										if unitHealth <= 16 and unitHealth > 1 then
											unit:ChangeDamage(unitHealth-1)
											Game.AddWorldViewText(0, 'LOC_EDEN_PIECE_DAMAGE', locationX, locationY)	
											--print("number1")
										elseif unitHealth <= 100 and unitHealth > 16 then
											unit:ChangeDamage(15)
											Game.AddWorldViewText(0, 'LOC_EDEN_PIECE_DAMAGE', locationX, locationY)	
											--print("number2")
										else
											local takePlace1 = 0;
										end				
									else
										if unitHealth <= 75 and unitHealth > 60 then
											unit:ChangeDamage(unitHealth-60)
											Game.AddWorldViewText(0, 'LOC_EDEN_PIECE_DAMAGE', locationX, locationY)	
											--print("number3")
										elseif unitHealth <= 100 and unitHealth > 75 then
											unit:ChangeDamage(15)
											Game.AddWorldViewText(0, 'LOC_EDEN_PIECE_DAMAGE', locationX, locationY)	
											--print("number4")
										else
											local takePlace2 = 0;
										end
									end		
								end					
							end	
						end
					end
				end
			end
			if unitTypeName == "UNIT_THE_SHROUD_OF_EDEN" then
				local locationX = unit:GetX()
				local locationY = unit:GetY()
				local pPlot = Map.GetPlot(locationX, locationY)
				if pPlot ~= nil then
					for loopp, pplotunit in ipairs(Units.GetUnitsInPlot(pPlot)) do
						if(pplotunit ~= nil) then
							local pplotunitInfo = GameInfo.Units[pplotunit:GetType()];
							if (pplotunitInfo) then
								local pplotunitTypeName = pplotunitInfo.UnitType;
								if pplotunitTypeName ~= "UNIT_THE_SHROUD_OF_EDEN" then
									--ɱ����λ
									--print("prepare to kill")
									--print(pplotunitTypeName)
									local unitID = pplotunit:GetID()
									table.insert(unitToBeKilledUnitID, unitID)		
									killUnitX = locationX
									killUnitY = locationY					
								end
							end
						end
					end
				end
			end
		end
	end
	--ɱ����λ
	if #unitToBeKilledUnitID ~= 0 then
		--print("into killing")
		for key, value in ipairs(unitToBeKilledUnitID) do
			local iUnit = UnitManager.GetUnit(pPlayerID, value)
			if iUnit~=nil then
				UnitManager.Kill(iUnit)
				Game.AddWorldViewText(0, 'LOC_THE_SHROUD_OF_EDEN_CURSE', killUnitX, killUnitY)			
				--print("unit killed succeed!")
			end
		end 
		unitToBeKilledUnitID = {}
		--print("end killing!")
	end
end

--���ø�λ�ɼ���
function SetPlotVisibilityAssassins(pPlayerID)
	local pPlayer = Players[pPlayerID];
	if pPlayer == nil then
		return
	end
	if (not pPlayer:IsHuman()) or (not pPlayer:IsMajor()) then
		return
	end
	local pPlayerCities = pPlayer:GetCities()
	if pPlayerCities == nil then 
		return
	end
	for looppPC, pPlayerCity in pPlayerCities:Members() do
		local pCityBuildings = pPlayerCity:GetBuildings()
		local pBuildingInfo = GameInfo.Buildings["BUILDING_THE_EYE"]
		if pCityBuildings ~= nil and pCityBuildings:HasBuilding(pBuildingInfo.Index) then 
			print("Has BUILDING_THE_EYE")
			SetPlotVisibilityActionAssassins(pPlayerID)
		end
	end
end


--��һغϽ���ʱ
function OnPlayerTurnDeactivatedAssassins(pPlayerID)

	local pPlayer = Players[pPlayerID];
	if pPlayer == nil then 
		return; 
	end
	FindPossibleUnitsAssassins(pPlayerID)
	SetPlotVisibilityAssassins(pPlayerID)
end 

Events.PlayerTurnDeactivated.Add(OnPlayerTurnDeactivatedAssassins)

--���ÿɼ���
function SetPlotVisibilityActionAssassins(pPlayerID)
	local pPlayer = Players[pPlayerID];
	if pPlayer == nil then
		return
	end
	local pCurPlayerVisibility = PlayersVisibility[pPlayerID];
	if(pCurPlayerVisibility ~= nil) then
		for iPlotIndex = 0, Map.GetPlotCount()-1, 1 do
			pPlot = Map.GetPlotByIndex(iPlotIndex)
			if pPlot~=nil then
				local locationX = pPlot:GetX()
				local locationY = pPlot:GetY()
				local pPlotImprovementType = pPlot:GetImprovementType()
				if pPlotImprovementType~=nil and pPlotImprovementType~=-1 then
					if GameInfo.Improvements[pPlotImprovementType].ImprovementType == "IMPROVEMENT_EDEN_PIECE_SUPPRESS" then
						local tNeighborPlots = Map.GetNeighborPlots(locationX, locationY, 3)
						for _, pNPlot in ipairs(tNeighborPlots) do
							iNPlotIndex = pNPlot:GetIndex()
							pCurPlayerVisibility:ChangeVisibilityCount(iNPlotIndex, 1);
						end
					end
				end
			end	
		end
		print("get sight success!")
	end
end

--�������ۡ���ɣ����ø�λ�ɼ���
function OnBuildingConstructedAssassins(pPlayerID, pCityID, pBuildingID, pPlotID, pbOriginalConstruction)
	local pPlayer = Players[pPlayerID]
	--print("into Assassins building constructed")
	--print("playerID", pPlayerID)	
	if pPlayer == nil then
		return;
	end
	if pPlayer:IsMajor() and pPlayer:IsHuman() then
		local building = GameInfo.Buildings[pBuildingID]
		if building ~= nil then
			if building.BuildingType=="BUILDING_THE_EYE" then
				SetPlotVisibilityActionAssassins(pPlayerID)
			end
		end
	end
end

GameEvents.BuildingConstructed.Add(OnBuildingConstructedAssassins)

--���������б�
function GetRiverList(RiverList,ri)
	for z = 0, RiverManager.GetNumFloodableRivers() - 1, 1 do
		local eRiverType = RiverManager.GetRiverTypeAtIndex(z);
		local namedRiver = GameInfo.NamedRivers[eRiverType];
		if namedRiver ~= nil then
			if (RiverManager.GetFloodplainPlots(GameInfo.NamedRivers[namedRiver.NamedRiverType].Index) ~= nil) then
				RiverList [ri + 1] = GameInfo.NamedRivers[namedRiver.NamedRiverType].Index;
				ri = ri + 1;
			end
		end
	end
	return RiverList, ri;
end

--������ɽ�б�
function GetVolcanoList(VolcanoList,vi)
	for z = 0, MapFeatureManager.GetNumNormalVolcanoes() - 1, 1 do
		local eVolcanoType = MapFeatureManager.GetVolcanoTypeAtIndex(z);
		local namedVolcano = GameInfo.NamedVolcanoes[eVolcanoType];
		if namedVolcano ~= nil then
			VolcanoList [vi + 1] = GameInfo.NamedVolcanoes[namedVolcano.NamedVolcanoType].Index;
			vi = vi + 1;
		end
	end
	return VolcanoList, vi;
end

--�����ֺ�
function CreateDisasterAssassins(VC,VolcanoList,RiverList,vi,ri)

	--���ø����ֺ�������Ƶ��
	--ɳ�����������磬����ѩ��쫷��ÿ�����࣬ϵ�������س̶ȣ���Ϊ3/2/1
	--��ɽ�緢�ͺ�ˮ���ġ��ɺ���ÿ�����࣬ϵ�������س̶ȣ���Ϊ6/4/2
	--��ô�ܵ���Ϊ��ɽ12+����12+�ɺ�10+ɳ����3+����ѩ3+������3+쫷�3=46

	local pRandomEventPoint=0;
	if vc then
		pRandomEventPoint = math.random(13,46);
	else
		pRandomEventPoint = math.random(1,46);
	end
	--print("into create disaster")
	local kEvent = {};
	if (0 < pRandomEventPoint and pRandomEventPoint < 13) then
		local UnitVID = math.random(1,vi);
		if (0 < pRandomEventPoint and pRandomEventPoint < 7) then
			print("RANDOM_EVENT_VOLCANO_GENTLE");
			print(GameInfo.NamedVolcanoes[VolcanoList [UnitVID]].NamedVolcanoType);
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_VOLCANO_GENTLE"].Index;
			kEvent.NamedVolcano = VolcanoList [UnitVID];
		else
			if (6 < pRandomEventPoint and pRandomEventPoint < 11) then
				print("RANDOM_EVENT_VOLCANO_CATASTROPHIC");
				print(GameInfo.NamedVolcanoes[VolcanoList [UnitVID]].NamedVolcanoType);
				kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_VOLCANO_CATASTROPHIC"].Index;
				kEvent.NamedVolcano = VolcanoList [UnitVID];
			else
				print("RANDOM_EVENT_VOLCANO_MEGACOLOSSAL");
				print(GameInfo.NamedVolcanoes[VolcanoList [UnitVID]].NamedVolcanoType);
				kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_VOLCANO_MEGACOLOSSAL"].Index;
				kEvent.NamedVolcano = VolcanoList [UnitVID];
			end
		end
	elseif  (12 < pRandomEventPoint and pRandomEventPoint < 25) then
		local UnitRID = math.random(1,ri);
		if (12 < pRandomEventPoint and pRandomEventPoint < 19) then
			print("RANDOM_EVENT_FLOOD_MODERATE");
			print(GameInfo.NamedRivers[RiverList [UnitRID]].NamedRiverType);
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_FLOOD_MODERATE"].Index;
			kEvent.NamedRiver = RiverList [UnitRID];
		else
			if (18 < pRandomEventPoint and pRandomEventPoint < 25) then
				print("RANDOM_EVENT_FLOOD_MAJOR");
				print(GameInfo.NamedRivers[RiverList [UnitRID]].NamedRiverType);
				kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_FLOOD_MAJOR"].Index;
				kEvent.NamedRiver = RiverList [UnitRID];
			else
				print("RANDOM_EVENT_FLOOD_1000_YEAR");
				print(GameInfo.NamedRivers[RiverList [UnitRID]].NamedRiverType);
				kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_FLOOD_1000_YEAR"].Index;
				kEvent.NamedRiver = RiverList [UnitRID];
			end
		end
	elseif  (24 < pRandomEventPoint and pRandomEventPoint< 28) then
		if (24 < pRandomEventPoint and pRandomEventPoint < 27) then
			print("RANDOM_EVENT_DUST_STORM_GRADIENT");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_DUST_STORM_GRADIENT"].Index;
		else
			print("RANDOM_EVENT_DUST_STORM_HABOOB");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_DUST_STORM_HABOOB"].Index;
		end
	elseif  (27 < pRandomEventPoint and pRandomEventPoint < 31) then
		if (27 < pRandomEventPoint and pRandomEventPoint < 30) then
			print("RANDOM_EVENT_BLIZZARD_SIGNIFICANT");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_BLIZZARD_SIGNIFICANT"].Index;
		else
			print("RANDOM_EVENT_BLIZZARD_CRIPPLING");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_BLIZZARD_CRIPPLING"].Index;
		end
	elseif (30 < pRandomEventPoint and pRandomEventPoint < 34) then
		if (30 < pRandomEventPoint and pRandomEventPoint < 33) then
			print("RANDOM_EVENT_TORNADO_FAMILY");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_TORNADO_FAMILY"].Index;
		else
			print("RANDOM_EVENT_TORNADO_OUTBREAK");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_TORNADO_OUTBREAK"].Index;
		end
	elseif (33 < pRandomEventPoint and pRandomEventPoint < 37) then
		if (33 < pRandomEventPoint and pRandomEventPoint < 36) then
			print("RANDOM_EVENT_HURRICANE_CAT_4");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_HURRICANE_CAT_4"].Index;
		else
			print("RANDOM_EVENT_HURRICANE_CAT_5");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_HURRICANE_CAT_5"].Index;
		end
	else 
		if (36 < pRandomEventPoint and pRandomEventPoint < 43) then
			print("RANDOM_EVENT_DROUGHT_MAJOR");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_DROUGHT_MAJOR"].Index;
		else
			print("RANDOM_EVENT_DROUGHT_EXTREME");
			kEvent.EventType = GameInfo.RandomEvents["RANDOM_EVENT_DROUGHT_EXTREME"].Index;
		end
	end
	GameRandomEvents.ApplyEvent(kEvent);
end


function OnPlayerTurnStartedAssassins(pPlayerID)
	if createDisasterJudge == 0 then
		return;
	end

	local pPlayer = Players[pPlayerID]
	if pPlayer ~= nil and pPlayer:IsMajor() then
		local currentTurn = Game.GetCurrentGameTurn();
		if (currentTurn-createDisasterStartTurn)%createDisasterFrequency==0 then
			--�����ֺ�
			--��Ѱ�һ�ɽ�������б���Ȼ�󴥷�����
			--print("into PROJECT_STARTING_GLOBAL_AURORA_BOREALIS_DEVICE")
			--local aliveMajorIDList = PlayerManager.GetAliveMajorIDs()
			--local iAliveMajorCount = PlayerManager.GetAliveMajorsCount();
			local VolcanoList = {};
			local vi = 0;
			local RiverList = {};
			local ri = 0;
			VolcanoList,vi = GetVolcanoList(VolcanoList,vi);
			RiverList,ri = GetRiverList(RiverList,ri);
			if VolcanoList ~= nil then
				CreateDisasterAssassins(true,VolcanoList,RiverList,vi,ri);
			else
				CreateDisasterAssassins(false,VolcanoList,RiverList,vi,ri);
			end
			--print("disaster created!")
		end
	end
end
GameEvents.PlayerTurnStarted.Add(OnPlayerTurnStartedAssassins)


--����ȫ�򼫹�װ�ú����������Ȼ�ֺ�
function OnCityProdCompAssassins(playerID, cityID, iConstructionType, itemID, bCancelled)
	if iConstructionType ~= 3 then
		--���������Ŀ�ͷ���
		return
	end
	local pPlayer = Players[playerID]
	if pPlayer == nil then
		return;
	end
	if not pPlayer:IsMajor() then
		return;
	end
	
	local project = GameInfo.Projects[itemID]
	if project == nil then
		return
	end
	if project.ProjectType == "PROJECT_STARTING_GLOBAL_AURORA_BOREALIS_DEVICE" then
		--print("into Assassins project completed")
		--print("playerID", playerID)
		if createDisasterJudge == 0 then
			createDisasterJudge = 1;
			createDisasterStartTurn = Game.GetCurrentGameTurn();
			
		elseif createDisasterJudge == 1 then
			if createDisasterFrequency > 1 then
				createDisasterFrequency = createDisasterFrequency-3
			end
		else
			print("won't happen")
		end	
	
	end
end

Events.CityProductionCompleted.Add(OnCityProdCompAssassins);

function OnKillUnitAssassins(playerID, unitID, locationX, locationY, pattPlayerID, pattUnitID, recoverValue, expValue)
	print("into hidden blade kill unit")
	local pUnit = UnitManager.GetUnit(playerID, unitID)
	if pUnit ~= nil then
		UnitManager.Kill(pUnit)
		Game.AddWorldViewText(0, 'LOC_HIDDEN_BLADE_KILL', locationX, locationY)
		print("hidden blade kill success")
		local pattUnit = UnitManager.GetUnit(pattPlayerID, pattUnitID)
		if pattUnit ~= nil then
			pattUnit:ChangeDamage(-recoverValue)
			print("recover success")
			local pattUnitExperience = pattUnit:GetExperience()
			if pattUnitExperience == nil then
				print("experience nil!")
				return
			end
			pattUnitExperience:ChangeExperience(expValue)
			print("grant experience success!")
		end
	end
	--print("end hidden blade kill unit")
end

ExposedMembers.AssassinsEM = ExposedMembers.AssassinsEM or {}
ExposedMembers.AssassinsEM.OnKillUnitAssassins = OnKillUnitAssassins

print("Assassins script initialized!")