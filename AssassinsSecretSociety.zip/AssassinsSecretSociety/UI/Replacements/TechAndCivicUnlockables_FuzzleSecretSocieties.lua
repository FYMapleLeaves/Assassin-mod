-- TechAndCivicUnlockables_FuzzleSecretSocieties
-- Author: 
-- DateCreated: 11/11/2022 12:43:08 PM
--------------------------------------------------------------
--���︴����UFO300���еĹ�ҵ����mod
function RemoveReplacedUnlockables(kUnlockables:table, playerId:number) 
	local kHasTraitMap:table = GetTraitMapForPlayer(playerId);
	
	local kUnlockMap:table = {};
	for i,v in ipairs(kUnlockables) do
		kUnlockMap[v[2]] = v;
	end

	for row in GameInfo.BuildingReplaces() do
        if(kUnlockMap[row.CivUniqueBuildingType]) then
            local uniqueBuilding = row.CivUniqueBuildingType;
            local SocietyBuilding = 0;
            for row in GameInfo.BuildingConditions() do
                if row.BuildingType == uniqueBuilding then
                    SocietyBuilding = 1;
                end
            end
            -- Only show the original buildings in the tech tree instead of the secret society building replacements
            if SocietyBuilding == 1 then
                kUnlockMap[row.CivUniqueBuildingType] = nil;
            else
                kUnlockMap[row.ReplacesBuildingType] = nil;
            end
        end
    end

	for row in GameInfo.DistrictReplaces() do
		if(kUnlockMap[row.CivUniqueDistrictType]) then
			kUnlockMap[row.ReplacesDistrictType] = nil;
		end
	end

	for row in GameInfo.ExcludedDistricts() do
		if(kHasTraitMap[row.TraitType]) then
			kUnlockMap[row.DistrictType] = nil;
		end
	end

	for row in GameInfo.UnitReplaces() do
		if(kUnlockMap[row.CivUniqueUnitType]) then
			kUnlockMap[row.ReplacesUnitType] = nil;
		end
	end
	
	local kResults:table = {};
	for k,v in pairs(kUnlockables) do
		if(kUnlockMap[v[2]])then
			table.insert(kResults, v);
		end
	end

	return kResults;
end