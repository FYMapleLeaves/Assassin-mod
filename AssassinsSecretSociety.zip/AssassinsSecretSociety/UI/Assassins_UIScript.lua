-- Assassins_UIScript
-- Author: yiboy
-- DateCreated: 11/16/2022 12:31:49 PM
--------------------------------------------------------------
function GetAppointedGovernorAssassins(playerID:number, governorTypeIndex:number)
	-- Make sure we're looking for a valid governor
	if playerID < 0 or governorTypeIndex < 0 then
		return nil;
	end

	-- Get the player governor list
	local pGovernorDef = GameInfo.Governors[governorTypeIndex];
	local pPlayer:table = Players[playerID];
	local pPlayerGovernors:table = pPlayer:GetGovernors();
	local bHasGovernors, tGovernorList = pPlayerGovernors:GetGovernorList();

	-- Find and return the governor from the governor list
	if pPlayerGovernors:HasGovernor(pGovernorDef.Hash) then
		for i,governor in ipairs(tGovernorList) do
			if governor:GetType() == governorTypeIndex then
				return governor;
			end
		end
	end

	-- Return nil if this player has not appointed that governor
	return nil;
end


--�̿͵�λ�����ɱ����
function OnCombatAssassins(pCombatResult)
	--�Ȼ�ȡ�����Ϣ
    local location = pCombatResult[CombatResultParameters.LOCATION];
    local defender = pCombatResult[CombatResultParameters.DEFENDER];
	local attacker = pCombatResult[CombatResultParameters.ATTACKER];
    local defInfo = defender[CombatResultParameters.ID];
	local attInfo = attacker[CombatResultParameters.ID];
    local pdefUnit = UnitManager.GetUnit(defInfo.player, defInfo.id);
	local pattUnit = UnitManager.GetUnit(attInfo.player, attInfo.id);
	local pCombatType = pCombatResult[CombatResultParameters.COMBAT_TYPE]
	
	if pattUnit == nil or pdefUnit == nil then 
		return;
	end

	if pdefUnit:IsDelayedDeath() then
		return;
	end
	local pattUnitType = GameInfo.Units[pattUnit:GetType()].UnitType 
	if pattUnitType ~= 'UNIT_ASSASSIN' then
		return;
	end

	local pPlayerID = attInfo.player
	local pPlayer = Players[pPlayerID];
	if pPlayer==nil then
		return;
	end
	--print("into assassin combat")
	--��ȡ�ܶ�
	local pPlayerGovernors:table = pPlayer:GetGovernors();
	if pPlayerGovernors == nil then
		return;
	end
	--print("111")
	local memberSocietyHash = pPlayerGovernors:GetSecretSociety();
	local pMemberSocietyDef:table = GameInfo.SecretSocieties[memberSocietyHash];
	if memberSocietyHash == nil then
		return;
	end
	--print(pMemberSocietyDef.SecretSocietyType)
	if pMemberSocietyDef.SecretSocietyType~="SECRETSOCIETY_ASSASSINS" then
		--print("not SECRETSOCIETY_ASSASSINS")
		return;
	end
	--print("222")
	local governorTypeIndex = GameInfo.Governors["GOVERNOR_ASSASSINS"].Index
	--print(governorTypeIndex)
	local governorInstance:table = GetAppointedGovernorAssassins(pPlayerID, governorTypeIndex);
	if governorInstance == nil then
		return;
	end
	local killLine = 0

	local promotiona1Def:table = GameInfo.GovernorPromotions["GOVERNOR_PROMOTION_ASSASSINS_1"];
	if governorInstance:HasPromotion(promotiona1Def.Hash) then
		--print("Has ASSASSINS_2")
		killLine = 12	
	end

	local promotion2Def:table = GameInfo.GovernorPromotions["GOVERNOR_PROMOTION_ASSASSINS_2"];
	if governorInstance:HasPromotion(promotion2Def.Hash) then
		--print("Has ASSASSINS_2")
		killLine = 24	
	end

	local promotion3Def:table = GameInfo.GovernorPromotions["GOVERNOR_PROMOTION_ASSASSINS_3"];
	if governorInstance:HasPromotion(promotion3Def.Hash) then
		--print("Has ASSASSINS_3")
		killLine = 36
	end

	local promotion4Def:table = GameInfo.GovernorPromotions["GOVERNOR_PROMOTION_ASSASSINS_4"];
	if governorInstance:HasPromotion(promotion4Def.Hash) then
		--print("Has ASSASSINS_4")
		killLine = 48
	end

	local pattUnitExperience = pattUnit:GetExperience()
	if pattUnitExperience == nil then
		--print("experience nil!")
		return
	end
	local pPromotion = GameInfo.UnitPromotions["PROMOTION_ASSASSIN_HIDDEN_BLADE"];
	if not pattUnitExperience:HasPromotion(pPromotion.Index) then
		--print("not have hidden blade")
		return
	end
	--print("has hidden blade")
	if killLine ~= 0 then 
		local unitDamageValue = pdefUnit:GetDamage()
		local unitHealth = 100 - unitDamageValue
		--print(333)
		--print("unitHealth", unitHealth)
		--print("killLine", killLine)
		--killLine = 100
		if unitHealth <= killLine then
			local locationX = pdefUnit:GetX()
			local locationY = pdefUnit:GetY()
			local defPlayerID = defInfo.player
			local unitID = pdefUnit:GetID()
			--print(444)
			local pattUnitID = pattUnit:GetID()
			local recoverValue = 10 + math.floor(0.5*killLine)
			local expValue = 4 + math.floor(0.2*killLine)
			--print("recoverValue", recoverValue)
			--print("expValue", expValue)
			--print(555)
			ExposedMembers.AssassinsEM.OnKillUnitAssassins(defPlayerID, unitID, locationX, locationY, pPlayerID, pattUnitID, recoverValue, expValue)
		end
	end
	--print("end assassin combat")
end
Events.Combat.Add(OnCombatAssassins)
print("Assassins UI Script initialized!")
