-- Assassins_Popup_Data
-- Author: yiboy
-- DateCreated: 11/11/2022 10:51:55 PM
--------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Mod_SecretSocietyPopupData (
Governor TEXT,
Society TEXT,
FileName TEXT
);

INSERT OR IGNORE INTO Mod_SecretSocietyPopupData (Governor, Society)
SELECT GovernorType, SecretSocietyType
FROM SecretSocieties;

UPDATE Mod_SecretSocietyPopupData
SET FileName = (SELECT PortraitImageSelected FROM Governors WHERE GovernorType = Governor);
